import { db } from 'hatchable';

export const access = 'user';
export const methods = ['GET'];

export default async function (req, res) {
  const { rows } = await db.query('SELECT id, service_name, amount, billing_cycle, renewal_date, status, category FROM subscriptions WHERE user_id = $1 ORDER BY renewal_date ASC', [req.user.id]);
  const today = new Date();
  const todayKey = today.toISOString().slice(0, 10);
  const weekEnd = new Date(today.getTime() + 7 * 86400000).toISOString().slice(0, 10);
  const active = rows.filter(x => x.status === 'Active');
  const monthly = active.reduce((sum, x) => sum + Number(x.amount) / (x.billing_cycle === 'Yearly' ? 12 : x.billing_cycle === 'Quarterly' ? 3 : 1), 0);
  const upcoming = active.filter(x => String(x.renewal_date).slice(0, 10) >= todayKey && String(x.renewal_date).slice(0, 10) <= weekEnd);
  const overdue = active.filter(x => String(x.renewal_date).slice(0, 10) < todayKey);
  return res.json({ total: rows.length, active: active.length, cancelled: rows.length - active.length, monthly_spending: Math.round(monthly * 100) / 100, yearly_spending: Math.round(monthly * 1200) / 100, upcoming_count: upcoming.length, overdue_count: overdue.length, upcoming, overdue, recent: rows.slice(0, 5) });
}