import { db } from 'hatchable';

export const access = 'user';
export const methods = ['GET', 'POST'];

function validDate(s) { return typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(Date.parse(s + 'T00:00:00Z')); }
function validate(b) {
  if (!b || typeof b.service_name !== 'string' || !b.service_name.trim()) return 'Service name is required.';
  if (!Number.isFinite(Number(b.amount)) || Number(b.amount) < 0) return 'Amount must be zero or more.';
  if (!['Monthly', 'Quarterly', 'Yearly'].includes(b.billing_cycle)) return 'Choose a valid billing cycle.';
  if (!['Active', 'Cancelled'].includes(b.status || 'Active')) return 'Choose a valid status.';
  if (!validDate(b.start_date) || !validDate(b.renewal_date)) return 'Enter valid start and renewal dates.';
  if (b.renewal_date < b.start_date) return 'Renewal date cannot be earlier than the start date.';
  return null;
}

export default async function (req, res) {
  const userId = req.user.id;
  if (req.method === 'GET') {
    const { rows } = await db.query('SELECT id, service_name, plan, amount, billing_cycle, to_char(start_date, $2) AS start_date, to_char(renewal_date, $2) AS renewal_date, status, category, created_at FROM subscriptions WHERE user_id = $1 ORDER BY renewal_date ASC, created_at DESC', [userId, 'YYYY-MM-DD']);
    return res.json({ subscriptions: rows });
  }
  const b = req.body || {};
  const error = validate(b);
  if (error) return res.status(400).json({ error });
  const { rows } = await db.query('INSERT INTO subscriptions (user_id, service_name, plan, amount, billing_cycle, start_date, renewal_date, status, category) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id, service_name, plan, amount, billing_cycle, start_date, renewal_date, status, category, created_at', [userId, b.service_name.trim(), String(b.plan || '').trim(), Number(b.amount), b.billing_cycle, b.start_date, b.renewal_date, b.status || 'Active', String(b.category || 'Other').trim()]);
  return res.status(201).json({ subscription: rows[0] });
}