import { db } from 'hatchable';

export const access = 'user';
export const methods = ['GET', 'PUT', 'DELETE'];

function validDate(s) { return typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(Date.parse(s + 'T00:00:00Z')); }
function validate(b) {
  if (!b || typeof b.service_name !== 'string' || !b.service_name.trim()) return 'Service name is required.';
  if (!Number.isFinite(Number(b.amount)) || Number(b.amount) < 0) return 'Amount must be zero or more.';
  if (!['Monthly', 'Quarterly', 'Yearly'].includes(b.billing_cycle)) return 'Choose a valid billing cycle.';
  if (!['Active', 'Cancelled'].includes(b.status)) return 'Choose a valid status.';
  if (!validDate(b.start_date) || !validDate(b.renewal_date)) return 'Enter valid start and renewal dates.';
  if (b.renewal_date < b.start_date) return 'Renewal date cannot be earlier than the start date.';
  return null;
}

export default async function (req, res) {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({ error: 'Invalid subscription ID.' });
  const userId = req.user.id;
  if (req.method === 'GET') {
    const { rows } = await db.query('SELECT id, service_name, plan, amount, billing_cycle, to_char(start_date, $3) AS start_date, to_char(renewal_date, $3) AS renewal_date, status, category, created_at FROM subscriptions WHERE id = $1 AND user_id = $2', [id, userId, 'YYYY-MM-DD']);
    if (!rows.length) return res.status(404).json({ error: 'Subscription not found.' });
    return res.json({ subscription: rows[0] });
  }
  if (req.method === 'DELETE') {
    const result = await db.query('DELETE FROM subscriptions WHERE id = $1 AND user_id = $2 RETURNING id', [id, userId]);
    if (!result.rows.length) return res.status(404).json({ error: 'Subscription not found.' });
    return res.json({ ok: true, id });
  }
  const b = req.body || {};
  const error = validate(b);
  if (error) return res.status(400).json({ error });
  const { rows } = await db.query('UPDATE subscriptions SET service_name=$3, plan=$4, amount=$5, billing_cycle=$6, start_date=$7, renewal_date=$8, status=$9, category=$10, updated_at=now() WHERE id=$1 AND user_id=$2 RETURNING id, service_name, plan, amount, billing_cycle, start_date, renewal_date, status, category, created_at', [id, userId, b.service_name.trim(), String(b.plan || '').trim(), Number(b.amount), b.billing_cycle, b.start_date, b.renewal_date, b.status, String(b.category || 'Other').trim()]);
  if (!rows.length) return res.status(404).json({ error: 'Subscription not found.' });
  return res.json({ subscription: rows[0] });
}